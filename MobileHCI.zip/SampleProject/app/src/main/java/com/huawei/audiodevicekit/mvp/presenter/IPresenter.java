package com.huawei.audiodevicekit.mvp.presenter;

/**
 * Created by Felix on 2016/8/16.
 * MVP模式中的P高层接口
 */
public interface IPresenter {
}
