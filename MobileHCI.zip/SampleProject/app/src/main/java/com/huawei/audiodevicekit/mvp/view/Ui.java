package com.huawei.audiodevicekit.mvp.view;


/**
 * Created by Felix on 2015/3/19.
 * View高层接口，通常是fragment/activity来实现此接口
 */
public interface Ui {
}
