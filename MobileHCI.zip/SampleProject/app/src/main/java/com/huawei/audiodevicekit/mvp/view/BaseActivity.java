package com.huawei.audiodevicekit.mvp.view;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.huawei.audiodevicekit.R;
import com.huawei.audiodevicekit.mvp.presenter.IPresenter;


/**
 * Created by Felix on 2015/3/26.
 * 封装重复操作绑定{@link Ui}的步骤，基础类Activity
 * <p>
 * 继承此类泛型参数传入实现对应接口的类。泛型类声明是为了显示类型，不传参数也行，但获取的类型为父类型。
 */

public abstract class BaseActivity<P extends IPresenter, U extends Ui> extends Activity implements UiFactory<P, U> {

    protected UiCreator<U> mUiAdapter;

    private P mPresenter;

    @Override
    public P getPresenter() {
        return mPresenter;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPresenter=createPresenter();
        mUiAdapter =new UiCreatorAdapter<>(mPresenter, getUiImplement());
        mUiAdapter.bindPresenterModel();
        MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.xiu);//创建mp对象，装载音频
        Button btn_send = findViewById(R.id.ll_send_cmd);
        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.start();//开始播放
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mUiAdapter.unbindPresenter();
    }



}
